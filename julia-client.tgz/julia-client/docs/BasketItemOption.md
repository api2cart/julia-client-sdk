# BasketItemOption


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] [default to nothing]
**value_id** | **String** |  | [optional] [default to nothing]
**name** | **String** |  | [optional] [default to nothing]
**value** | **String** |  | [optional] [default to nothing]
**used_in_combination** | **Bool** |  | [optional] [default to nothing]
**additional_fields** | **Any** |  | [optional] [default to nothing]
**custom_fields** | **Any** |  | [optional] [default to nothing]


[[Back to Model list]](../README.md#models) [[Back to API list]](../README.md#api-endpoints) [[Back to README]](../README.md)


