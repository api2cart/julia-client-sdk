# AccountConfigUpdate200Response


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**return_code** | **Int64** |  | [optional] [default to nothing]
**return_message** | **String** |  | [optional] [default to nothing]
**result** | [***AccountConfigUpdate200ResponseResult**](AccountConfigUpdate200ResponseResult.md) |  | [optional] [default to nothing]


[[Back to Model list]](../README.md#models) [[Back to API list]](../README.md#api-endpoints) [[Back to README]](../README.md)


