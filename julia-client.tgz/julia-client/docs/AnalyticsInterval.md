# AnalyticsInterval


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date_from** | **String** |  | [optional] [default to nothing]
**date_to** | **String** |  | [optional] [default to nothing]
**metrics** | [***AnalyticsMetric**](AnalyticsMetric.md) |  | [optional] [default to nothing]
**additional_fields** | **Any** |  | [optional] [default to nothing]
**custom_fields** | **Any** |  | [optional] [default to nothing]


[[Back to Model list]](../README.md#models) [[Back to API list]](../README.md#api-endpoints) [[Back to README]](../README.md)


